package vn.anbinh.aichoigame

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var trangThai: TextView
    private lateinit var nhatKy: TextView
    private var soViTri: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cd = CaiDat.doc(this)
        val dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()

        val goc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad * 3)
        }
        fun nhan(s: String) = TextView(this).apply {
            text = s
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, pad, 0, 4)
        }

        goc.addView(TextView(this).apply {
            text = "AI Chơi Game"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
        })
        trangThai = TextView(this).apply { textSize = 15f; setPadding(0, pad / 2, 0, pad / 2) }
        goc.addView(trangThai)

        goc.addView(Button(this).apply {
            text = "Bật quyền Trợ năng cho app"
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Tìm \"AI Chơi Game\" trong danh sách và bật lên", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        goc.addView(Button(this).apply {
            text = "Mở thông tin app (nếu bị chặn bật Trợ năng)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = android.net.Uri.parse("package:$packageName")
                })
            }
        })

        // ================= AUTO (không cần AI) =================
        goc.addView(TextView(this).apply {
            text = "\nCHẾ ĐỘ AUTO: không cần AI, không cần key, miễn phí"
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF2E7D32.toInt())
        })
        goc.addView(TextView(this).apply {
            text = "1) Mở game, bấm nút ⚙ trên bảng nút nổi rồi chạm lần lượt vào các nút game theo hướng dẫn (làm 1 lần).\n2) Bấm ▶ Auto để chạy, bấm lần nữa để dừng."
            textSize = 14f
        })
        val soViTri = TextView(this).apply { textSize = 14f; setPadding(0, pad / 2, 0, 0) }
        goc.addView(soViTri)
        this.soViTri = soViTri

        goc.addView(nhan("Auto làm gì"))
        val nhomAuto = RadioGroup(this)
        val rbDanh = RadioButton(this).apply { text = "Đánh quái tại chỗ (treo luyện cấp)"; id = View.generateViewId() }
        val rbNv = RadioButton(this).apply { text = "Làm nhiệm vụ (bấm bảng nhiệm vụ để tự đi) + đánh"; id = View.generateViewId() }
        nhomAuto.addView(rbDanh); nhomAuto.addView(rbNv)
        nhomAuto.check(if (cd.autoCheDo == "nhiem_vu") rbNv.id else rbDanh.id)
        goc.addView(nhomAuto)

        fun oSo(nhanChu: String, giaTri: String, thapPhan: Boolean = false): EditText {
            goc.addView(nhan(nhanChu))
            val o = EditText(this).apply {
                setText(giaTri)
                inputType = InputType.TYPE_CLASS_NUMBER or (if (thapPhan) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0)
                isSingleLine = true
            }
            goc.addView(o)
            return o
        }
        val oMau = oSo("Uống bình máu khi máu dưới (%)", cd.nguongMau.toString())
        val oMana = oSo("Uống bình mana khi mana dưới (%)", cd.nguongMana.toString())
        val oHoiChieu = oSo("Hồi chiêu kỹ năng (giây)", cd.giayHoiChieu.toString(), true)
        val oNhiemVu = oSo("Làm nhiệm vụ: bấm bảng nhiệm vụ mỗi (giây)", cd.giayNhiemVu.toString())
        val oDiTuan = oSo("Đi tuần tìm quái mỗi (giây, 0 = đứng yên)", cd.giayDiTuan.toString())
        goc.addView(Button(this).apply {
            text = "Xóa vị trí nút đã ghi"
            setOnClickListener {
                ViTri.xoa(this@MainActivity)
                Toast.makeText(this@MainActivity, "Đã xóa. Vào game bấm ⚙ để ghi lại", Toast.LENGTH_SHORT).show()
                capNhat()
            }
        })

        // ================= AI (tùy chọn) =================
        goc.addView(TextView(this).apply {
            text = "\nCHẾ ĐỘ AI (tùy chọn, cần key): AI tự nhìn và suy luận"
            textSize = 17f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFF1565C0.toInt())
        })
        goc.addView(nhan("API key (Claude, Gemini, OpenRouter hoặc Groq)"))
        val oKey = EditText(this).apply {
            setText(cd.apiKey)
            hint = "sk-ant-... / AIza... / sk-or-... / gsk_..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            isSingleLine = true
        }
        goc.addView(oKey)

        goc.addView(nhan("Việc AI làm"))
        val nhom = RadioGroup(this)
        val idTheoCheDo = HashMap<Int, String>()
        Prompts.TEN_CHE_DO.forEach { (ma, ten) ->
            val rb = RadioButton(this).apply { text = ten; id = View.generateViewId() }
            idTheoCheDo[rb.id] = ma
            nhom.addView(rb)
            if (ma == cd.cheDo) nhom.check(rb.id)
        }
        goc.addView(nhom)

        goc.addView(nhan("Model AI"))
        val oModel = EditText(this).apply { setText(cd.model); isSingleLine = true }
        goc.addView(oModel)
        goc.addView(TextView(this).apply {
            text = "Để trống là app tự chọn theo loại key:\n• sk-ant-...: Claude (trả phí, chơi tốt nhất)\n• AIza...: Gemini (miễn phí có giới hạn)\n• sk-or-...: OpenRouter (model miễn phí, tự đổi model dự phòng)\n• gsk_...: Groq (miễn phí, nhanh)"
            textSize = 12f
            setTextColor(Color.GRAY)
        })

        goc.addView(nhan("Số bước tối đa mỗi lần chạy"))
        val oSoBuoc = EditText(this).apply {
            setText(cd.soBuoc.toString()); inputType = InputType.TYPE_CLASS_NUMBER; isSingleLine = true
        }
        goc.addView(oSoBuoc)

        goc.addView(nhan("Nghỉ giữa các bước (giây)"))
        val oCho = EditText(this).apply {
            setText(cd.choGiay.toString())
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            isSingleLine = true
        }
        goc.addView(oCho)

        goc.addView(nhan("Dặn thêm AI (không bắt buộc)"))
        val oGhiChu = EditText(this).apply {
            setText(cd.ghiChu)
            hint = "Ví dụ: Nhân vật hệ Võ, bình máu ở ô số 4, đánh quái ở bãi phía đông thành"
            minLines = 2
        }
        goc.addView(oGhiChu)

        goc.addView(Button(this).apply {
            text = "LƯU CÀI ĐẶT"
            setOnClickListener {
                CaiDat(
                    apiKey = oKey.text.toString(),
                    model = oModel.text.toString(),
                    cheDo = idTheoCheDo[nhom.checkedRadioButtonId] ?: "ca_hai",
                    soBuoc = oSoBuoc.text.toString().toIntOrNull()?.coerceIn(1, 100_000) ?: 500,
                    choGiay = oCho.text.toString().toDoubleOrNull()?.coerceIn(0.0, 30.0) ?: 1.2,
                    ghiChu = oGhiChu.text.toString(),
                    autoCheDo = if (nhomAuto.checkedRadioButtonId == rbNv.id) "nhiem_vu" else "danh_quai",
                    nguongMau = oMau.text.toString().toIntOrNull()?.coerceIn(0, 100) ?: 40,
                    nguongMana = oMana.text.toString().toIntOrNull()?.coerceIn(0, 100) ?: 30,
                    giayHoiChieu = oHoiChieu.text.toString().toDoubleOrNull()?.coerceIn(0.2, 120.0) ?: 3.0,
                    giayNhiemVu = oNhiemVu.text.toString().toIntOrNull()?.coerceIn(3, 600) ?: 20,
                    giayDiTuan = oDiTuan.text.toString().toIntOrNull()?.coerceIn(0, 600) ?: 0
                ).luu(this@MainActivity)
                Toast.makeText(this@MainActivity, "Đã lưu", Toast.LENGTH_SHORT).show()
                capNhat()
            }
        })

        goc.addView(TextView(this).apply {
            text = "\nBảng nút nổi trong game: ▶ Auto · ▶ AI · ⚙ ghi vị trí. Giữ và kéo để dời bảng. Nhớ bấm LƯU CÀI ĐẶT sau khi sửa."
            textSize = 14f
        })

        goc.addView(nhan("Nhật ký (mới nhất ở trên)"))
        val hang = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hang.addView(Button(this).apply { text = "Tải lại"; setOnClickListener { capNhat() } })
        hang.addView(Button(this).apply {
            text = "Xóa nhật ký"
            setOnClickListener { NhatKy.xoa(this@MainActivity); capNhat() }
        })
        hang.addView(Button(this).apply {
            text = "Xóa sổ tay AI"
            setOnClickListener {
                SoTay(this@MainActivity).xoa()
                Toast.makeText(this@MainActivity, "AI sẽ học lại game từ đầu", Toast.LENGTH_SHORT).show()
            }
        })
        goc.addView(hang)

        nhatKy = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
        }
        goc.addView(nhatKy)

        setContentView(ScrollView(this).apply { addView(goc) })
    }

    override fun onResume() {
        super.onResume()
        capNhat()
    }

    private fun capNhat() {
        val cd = CaiDat.doc(this)
        trangThai.text = when {
            AiService.instance == null -> "⚠️ Chưa bật quyền Trợ năng. Bấm nút bên dưới, tìm \"AI Chơi Game\" và bật lên."
            cd.apiKey.isBlank() -> "✅ Đã bật quyền. Dùng được ▶ Auto (miễn phí). Muốn dùng ▶ AI thì nhập key ở phần AI."
            else -> "✅ Sẵn sàng: ▶ Auto và ▶ AI (đang dùng " + NhaCungCap.ten(cd.apiKey) + ")."
        }
        val n = ViTri.soDaGhi(this)
        soViTri?.text = if (ViTri.lay(this, "danh") == null) "⚠️ Chưa ghi vị trí nút (đã ghi $n/${ViTri.DS.size})"
        else "✅ Đã ghi $n/${ViTri.DS.size} vị trí nút"
        nhatKy.text = NhatKy.doc(this)
    }

}
