package vn.anbinh.aichoigame

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Gọi các dịch vụ theo chuẩn OpenAI (OpenRouter, Groq...).
 * Không dùng "tools" vì nhiều model miễn phí không hỗ trợ: AI trả về JSON dạng chữ rồi app tự đọc.
 * Nếu model không tồn tại / không đọc được ảnh thì tự chuyển sang model dự phòng kế tiếp.
 */
class OpenAICompatClient(
    private val key: String,
    private val baseUrl: String,
    models: List<String>,
    private val ten: String,
    private val khoangCachMs: Long
) : AiClient {

    private val dsModel = models.distinct()
    private var viTri = 0
    private var lanGoiCuoi = 0L

    override fun hoi(heThong: String, chu: String, anhB64: String): JSONObject {
        var loiCuoi = ""
        var lan = 0
        while (lan < 5) {
            if (viTri >= dsModel.size) {
                throw LoiNghiemTrong("$ten: không model nào dùng được ($loiCuoi). Thử điền tên model khác vào ô Model AI")
            }
            val model = dsModel[viTri]
            val cho = khoangCachMs - (System.currentTimeMillis() - lanGoiCuoi)
            if (cho > 0) Thread.sleep(cho)
            lanGoiCuoi = System.currentTimeMillis()

            val body = JSONObject()
                .put("model", model)
                .put("max_tokens", 1024)
                .put(
                    "messages", JSONArray()
                        .put(JSONObject().put("role", "system").put("content", heThong + "\n\n" + Prompts.huongDanJson()))
                        .put(
                            JSONObject().put("role", "user").put(
                                "content", JSONArray()
                                    .put(JSONObject().put("type", "text").put("text", chu))
                                    .put(
                                        JSONObject().put("type", "image_url").put(
                                            "image_url", JSONObject().put("url", "data:image/jpeg;base64,$anhB64")
                                        )
                                    )
                            )
                        )
                )
                .toString()

            try {
                val c = URL("$baseUrl/chat/completions").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 20_000
                c.readTimeout = 120_000
                c.setRequestProperty("Authorization", "Bearer $key")
                c.setRequestProperty("content-type", "application/json")
                c.setRequestProperty("HTTP-Referer", "https://github.com/thanproden20-source/aigame")
                c.setRequestProperty("X-Title", "AI Choi Game")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

                val ma = c.responseCode
                val luong = if (ma in 200..299) c.inputStream else c.errorStream
                val txt = luong?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                c.disconnect()
                val thap = txt.lowercase()

                when {
                    ma in 200..299 -> {
                        val goc = JSONObject(txt)
                        val loiTrongBody = goc.optJSONObject("error")
                        if (loiTrongBody != null) {
                            loiCuoi = "$model: " + loiTrongBody.optString("message").take(120)
                            viTri++
                            continue
                        }
                        val noiDung = goc.optJSONArray("choices")?.optJSONObject(0)
                            ?.optJSONObject("message")?.optString("content") ?: ""
                        val kq = docJson(noiDung)
                        if (kq != null) return kq
                        loiCuoi = "AI trả lời không đúng dạng"
                    }
                    ma == 401 -> throw LoiNghiemTrong("Key $ten sai hoặc đã bị xóa")
                    ma == 402 -> throw LoiNghiemTrong("$ten: tài khoản hết tiền/hết lượt (mã 402)")
                    ma == 403 && !thap.contains("model") -> throw LoiNghiemTrong("Key $ten không có quyền: " + txt.take(150))
                    ma == 429 -> {
                        loiCuoi = "hết lượt miễn phí tạm thời"
                        lan++
                        Thread.sleep(20_000L * lan)
                        continue
                    }
                    ma == 404 || ma == 400 || ma == 403 || ma == 422 -> {
                        // thường là model không còn / không đọc được ảnh -> đổi model dự phòng
                        loiCuoi = "$model: " + txt.take(120)
                        viTri++
                        continue
                    }
                    else -> loiCuoi = "máy chủ $ten bận (mã $ma)"
                }
            } catch (e: LoiNghiemTrong) {
                throw e
            } catch (e: Exception) {
                loiCuoi = "lỗi mạng: " + (e.message ?: e.javaClass.simpleName)
            }
            lan++
            Thread.sleep(5000L * lan)
        }
        throw LoiNghiemTrong("Gọi $ten thất bại: $loiCuoi")
    }

    /** Lấy đối tượng JSON đầu tiên trong câu trả lời (bỏ qua chữ thừa, dấu ```). */
    private fun docJson(s: String): JSONObject? {
        val dau = s.indexOf('{')
        val cuoi = s.lastIndexOf('}')
        if (dau < 0 || cuoi <= dau) return null
        return try {
            val o = JSONObject(s.substring(dau, cuoi + 1))
            if (o.optJSONArray("thao_tac") == null) null else o
        } catch (_: Exception) {
            null
        }
    }
}
