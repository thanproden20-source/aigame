package vn.anbinh.aichoigame

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Lỗi không nên thử lại (sai key, hết tiền...). */
class LoiNghiemTrong(msg: String) : Exception(msg)

/** Giao diện chung cho các nhà cung cấp AI. */
interface AiClient {
    fun hoi(heThong: String, chu: String, anhB64: String): JSONObject
}

object NhaCungCap {
    const val MODEL_GEMINI = "gemini-flash-latest"

    // Model miễn phí có đọc được ảnh; model nào không còn thì app tự chuyển sang model kế tiếp
    val MODEL_OPENROUTER = listOf(
        "google/gemma-4-31b-it:free",
        "google/gemma-3-27b-it:free",
        "qwen/qwen2.5-vl-72b-instruct:free",
        "meta-llama/llama-4-maverick:free",
        "mistralai/mistral-small-3.2-24b-instruct:free"
    )
    val MODEL_GROQ = listOf(
        "meta-llama/llama-4-scout-17b-16e-instruct",
        "meta-llama/llama-4-maverick-17b-128e-instruct"
    )

    fun laGemini(key: String) = key.trim().startsWith("AIza")

    fun ten(key: String): String {
        val k = key.trim()
        return when {
            k.startsWith("AIza") -> "Gemini"
            k.startsWith("sk-or-") -> "OpenRouter"
            k.startsWith("gsk_") -> "Groq"
            else -> "Claude"
        }
    }

    /** Chọn đúng nhà cung cấp theo dạng key; model trống hoặc không khớp thì dùng model mặc định. */
    fun tao(key: String, model: String): AiClient {
        val k = key.trim()
        val m = model.trim()
        val laTenRieng = m.isNotEmpty() && !m.startsWith("claude") && !m.startsWith("gemini")
        return when (ten(k)) {
            "Gemini" -> GeminiClient(k, if (m.startsWith("gemini")) m else MODEL_GEMINI)
            "OpenRouter" -> OpenAICompatClient(
                k, "https://openrouter.ai/api/v1",
                (if (laTenRieng) listOf(m) else emptyList()) + MODEL_OPENROUTER, "OpenRouter", 3500
            )
            "Groq" -> OpenAICompatClient(
                k, "https://api.groq.com/openai/v1",
                (if (laTenRieng) listOf(m) else emptyList()) + MODEL_GROQ, "Groq", 2500
            )
            else -> ClaudeClient(k, if (m.startsWith("claude")) m else CaiDat.MODEL_MAC_DINH)
        }
    }
}

class ClaudeClient(private val key: String, private val model: String) : AiClient {

    override fun hoi(heThong: String, chu: String, anhB64: String): JSONObject {
        val noiDung = JSONArray()
            .put(JSONObject().put("type", "text").put("text", chu))
            .put(
                JSONObject().put("type", "image").put(
                    "source", JSONObject()
                        .put("type", "base64")
                        .put("media_type", "image/jpeg")
                        .put("data", anhB64)
                )
            )
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 1024)
            .put(
                "system", JSONArray().put(
                    JSONObject().put("type", "text").put("text", heThong)
                        .put("cache_control", JSONObject().put("type", "ephemeral"))
                )
            )
            .put("tools", JSONArray().put(Prompts.congCu()))
            .put("tool_choice", JSONObject().put("type", "tool").put("name", "hanh_dong"))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", noiDung)))
            .toString()

        var loiCuoi = ""
        for (lan in 0 until 4) {
            try {
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 20_000
                c.readTimeout = 120_000
                c.setRequestProperty("x-api-key", key)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.setRequestProperty("content-type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

                val ma = c.responseCode
                val luong = if (ma in 200..299) c.inputStream else c.errorStream
                val txt = luong?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                c.disconnect()

                when {
                    ma in 200..299 -> {
                        val ct = JSONObject(txt).optJSONArray("content") ?: JSONArray()
                        for (i in 0 until ct.length()) {
                            val k = ct.getJSONObject(i)
                            if (k.optString("type") == "tool_use") return k.getJSONObject("input")
                        }
                        loiCuoi = "AI không trả về thao tác"
                    }
                    ma == 401 || ma == 403 -> throw LoiNghiemTrong("Key Claude sai hoặc không có quyền (key Gemini bắt đầu bằng AIza, OpenRouter bằng sk-or-, Groq bằng gsk_)")
                    ma == 400 -> throw LoiNghiemTrong("Bị từ chối (kiểm tra tên model, số dư tài khoản): " + txt.take(200))
                    else -> loiCuoi = "máy chủ AI bận (mã $ma)"
                }
            } catch (e: LoiNghiemTrong) {
                throw e
            } catch (e: Exception) {
                loiCuoi = "lỗi mạng: " + (e.message ?: e.javaClass.simpleName)
            }
            Thread.sleep(5000L * (lan + 1))
        }
        throw LoiNghiemTrong("Gọi AI thất bại: $loiCuoi")
    }
}
