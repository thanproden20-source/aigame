package vn.anbinh.aichoigame

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.GestureResultCallback
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Dịch vụ Trợ năng:
 *  - Bảng nút nổi: [▶ Auto] chạy theo luật, không cần AI · [▶ AI] AI suy luận · [⚙] ghi vị trí nút
 *  - Chụp màn hình, tự chạm/vuốt.
 */
class AiService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: AiService? = null
        private const val CANH_DAI_ANH = 1024   // cạnh dài ảnh gửi AI (tiết kiệm phí)
        private const val SO_BUOC_NHO = 12
        private val MAU_XANH = 0xCC1565C0.toInt()
        private val MAU_LUC = 0xCC2E7D32.toInt()
        private val MAU_DO = 0xCCC62828.toInt()
        private val MAU_XAM = 0xCC455A64.toInt()
    }

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null

    // bảng nút nổi
    private var bang: LinearLayout? = null
    private var nutAuto: TextView? = null
    private var nutAi: TextView? = null
    private var dongTrangThai: TextView? = null

    // lớp phủ ghi vị trí
    private var lopGhi: FrameLayout? = null

    @Volatile
    private var dangChay = false

    @Volatile
    private var cheDoChay = ""      // "auto" | "ai"
    private var luong: Thread? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        taoBangNut()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        dangChay = false
        bang?.let { v -> runCatching { wm?.removeView(v) } }
        lopGhi?.let { v -> runCatching { wm?.removeView(v) } }
        bang = null
        lopGhi = null
        instance = null
        super.onDestroy()
    }

    private fun kichThuocManHinh(): Pair<Int, Int> {
        val b = wm!!.currentWindowMetrics.bounds
        return Pair(b.width(), b.height())
    }

    // ------------------------------------------------------------ bảng nút nổi
    private fun taoNut(chu: String, mau: Int): TextView = TextView(this).apply {
        text = chu
        setTextColor(Color.WHITE)
        textSize = 13f
        setPadding(24, 14, 24, 14)
        background = GradientDrawable().apply { cornerRadius = 30f; setColor(mau) }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun taoBangNut() {
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 220
        }

        val hang = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val a = taoNut("▶ Auto", MAU_LUC)
        val b = taoNut("▶ AI", MAU_XANH)
        val g = taoNut("⚙", MAU_XAM)
        hang.addView(a)
        hang.addView(b, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = 10 })
        hang.addView(g, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = 10 })

        val tt = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(16, 6, 16, 6)
            maxWidth = (resources.displayMetrics.widthPixels * 0.45).toInt()
            background = GradientDrawable().apply { cornerRadius = 20f; setColor(0x99000000.toInt()) }
            visibility = View.GONE
        }
        val khung = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(hang)
            addView(tt, LinearLayout.LayoutParams(-2, -2).apply { topMargin = 6 })
        }

        // Kéo để dời cả bảng, chạm để bấm nút
        fun ganCham(v: View, khiBam: () -> Unit) {
            var dauX = 0f
            var dauY = 0f
            var gocX = 0
            var gocY = 0
            var keo = false
            v.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        dauX = e.rawX; dauY = e.rawY; gocX = lp.x; gocY = lp.y; keo = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - dauX
                        val dy = e.rawY - dauY
                        if (abs(dx) > 15 || abs(dy) > 15) keo = true
                        if (keo) {
                            lp.x = gocX + dx.toInt()
                            lp.y = gocY + dy.toInt()
                            runCatching { wm?.updateViewLayout(khung, lp) }
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!keo) khiBam()
                }
                true
            }
        }
        ganCham(a) { bamNut("auto") }
        ganCham(b) { bamNut("ai") }
        ganCham(g) { batDauGhiViTri() }
        ganCham(tt) { }

        runCatching { wm?.addView(khung, lp) }.onSuccess {
            bang = khung; nutAuto = a; nutAi = b; dongTrangThai = tt
        }
    }

    private fun hienTrangThai(s: String) {
        main.post {
            val dangAuto = dangChay && cheDoChay == "auto"
            val dangAi = dangChay && cheDoChay == "ai"
            nutAuto?.text = if (dangAuto) "■ Dừng" else "▶ Auto"
            nutAi?.text = if (dangAi) "■ Dừng" else "▶ AI"
            (nutAuto?.background as? GradientDrawable)?.setColor(if (dangAuto) MAU_DO else MAU_LUC)
            (nutAi?.background as? GradientDrawable)?.setColor(if (dangAi) MAU_DO else MAU_XANH)
            dongTrangThai?.apply {
                text = s.take(90)
                visibility = if (s.isBlank()) View.GONE else View.VISIBLE
            }
        }
    }

    private fun bamNut(loai: String) {
        if (dangChay) {
            val cu = cheDoChay
            dangChay = false
            hienTrangThai("đang dừng...")
            if (cu == loai) return
        }
        if (luong?.isAlive == true) {
            hienTrangThai("đang dừng lượt trước, bấm lại sau 1-2 giây")
            return
        }
        val cd = CaiDat.doc(this)
        if (loai == "ai") {
            if (cd.apiKey.isBlank()) {
                hienTrangThai("Chưa có API key. Dùng nút ▶ Auto (không cần key) hoặc mở app nhập key")
                return
            }
            dangChay = true
            cheDoChay = "ai"
            hienTrangThai("AI bắt đầu")
            luong = thread(name = "ai-choi-game") { vongLap(cd) }
        } else {
            if (ViTri.lay(this, "danh") == null) {
                hienTrangThai("Chưa ghi vị trí nút. Bấm ⚙ để ghi trước")
                return
            }
            dangChay = true
            cheDoChay = "auto"
            hienTrangThai("Auto bắt đầu")
            luong = thread(name = "auto-choi-game") { vongLapAuto(cd) }
        }
    }

    // ------------------------------------------------------------ ghi vị trí nút
    @SuppressLint("ClickableViewAccessibility")
    private fun batDauGhiViTri() {
        if (dangChay) {
            hienTrangThai("Dừng Auto/AI trước rồi mới ghi vị trí")
            return
        }
        if (lopGhi != null) return
        var buoc = 0
        val (rongMH, caoMH) = kichThuocManHinh()

        val huongDan = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(30, 20, 30, 20)
            background = GradientDrawable().apply { cornerRadius = 24f; setColor(0xDD000000.toInt()) }
        }
        val boQua = taoNut("Bỏ qua", MAU_XAM)
        val xong = taoNut("Xong", MAU_LUC)
        val hang = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(boQua)
            addView(xong, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = 20 })
        }
        val hop = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(huongDan)
            addView(hang, LinearLayout.LayoutParams(-2, -2).apply { topMargin = 12 })
        }
        val lop = FrameLayout(this).apply {
            setBackgroundColor(0x33000000)
            addView(hop, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = (caoMH * 0.30).toInt()
            })
        }

        fun ketThuc() {
            lopGhi?.let { v -> runCatching { wm?.removeView(v) } }
            lopGhi = null
            bang?.visibility = View.VISIBLE
            hienTrangThai("Đã ghi ${ViTri.soDaGhi(this)} vị trí. Bấm ▶ Auto để chạy")
        }

        fun capNhat() {
            if (buoc >= ViTri.DS.size) {
                ketThuc(); return
            }
            val d = ViTri.DS[buoc]
            val daCo = if (ViTri.lay(this, d.ma) != null) "\n(đã ghi trước đó, chạm lại để sửa)" else ""
            huongDan.text = "Bước ${buoc + 1}/${ViTri.DS.size}\nChạm vào: ${d.ten}" +
                (if (d.batBuoc) "" else "\nKhông có thì bấm Bỏ qua") + daCo
            boQua.visibility = if (d.batBuoc) View.GONE else View.VISIBLE
        }

        lop.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_UP && buoc < ViTri.DS.size) {
                ViTri.luu(this, ViTri.DS[buoc].ma, e.rawX / rongMH, e.rawY / caoMH)
                buoc++
                capNhat()
            }
            true
        }
        boQua.setOnClickListener { buoc++; capNhat() }
        xong.setOnClickListener {
            if (ViTri.lay(this, "danh") == null) {
                huongDan.text = "Cần ghi ít nhất nút ĐÁNH.\nChạm vào nút ĐÁNH trong game"
                buoc = 0
            } else ketThuc()
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        runCatching { wm?.addView(lop, lp) }.onSuccess {
            lopGhi = lop
            bang?.visibility = View.GONE
            capNhat()
        }
    }

    // ------------------------------------------------------------ AUTO (không cần AI)
    /** Đổi vị trí đã ghi (tỉ lệ) thành tọa độ thật trên màn hình. */
    private fun toaDo(ma: String): Pair<Float, Float>? {
        val t = ViTri.lay(this, ma) ?: return null
        val (w, h) = kichThuocManHinh()
        return Pair(t.first * w, t.second * h)
    }

    private fun chamDiem(ma: String): Boolean {
        val p = toaDo(ma) ?: return false
        return cuChi(Path().apply { moveTo(p.first, p.second) }, 50)
    }

    /** Đọc % thanh máu/mana: lấy mẫu điểm ảnh dọc đoạn từ đầu trái tới đầu phải, đếm điểm có màu. */
    private fun docThanh(anh: Bitmap, trai: String, phai: String, laMau: Boolean): Int? {
        val a = ViTri.lay(this, trai) ?: return null
        val b = ViTri.lay(this, phai) ?: return null
        val n = 40
        var co = 0
        for (i in 0 until n) {
            val t = (i + 0.5f) / n
            val x = ((a.first + (b.first - a.first) * t) * anh.width).toInt().coerceIn(0, anh.width - 1)
            val y = ((a.second + (b.second - a.second) * t) * anh.height).toInt().coerceIn(0, anh.height - 1)
            val p = anh.getPixel(x, y)
            val r = Color.red(p)
            val g = Color.green(p)
            val bl = Color.blue(p)
            val dung = if (laMau) r > 120 && r > g * 1.6 && r > bl * 1.6
            else bl > 120 && bl > r * 1.3 && bl > g * 0.9
            if (dung) co++
        }
        return co * 100 / n
    }

    private fun vongLapAuto(cd: CaiDat) {
        NhatKy.ghi(this, "=== Auto bắt đầu: ${cd.autoCheDo}, máu<${cd.nguongMau}%, mana<${cd.nguongMana}%")
        val kyNang = listOf("kn1", "kn2", "kn3", "kn4").filter { ViTri.lay(this, it) != null }
        val lanKyNang = HashMap<String, Long>()
        val coThanh = ViTri.lay(this, "mau_trai") != null && ViTri.lay(this, "mau_phai") != null
        val coMana = ViTri.lay(this, "mana_trai") != null && ViTri.lay(this, "mana_phai") != null
        var lanDocThanh = 0L
        var lanUongMau = 0L
        var lanUongMana = 0L
        var lanNhiemVu = 0L
        var lanDiTuan = System.currentTimeMillis()
        var mau: Int? = null
        var mana: Int? = null
        var soLan = 0L
        val batDau = System.currentTimeMillis()

        try {
            while (dangChay) {
                val bay = System.currentTimeMillis()

                // 1) Đọc thanh máu / mana mỗi ~1,2 giây
                if ((coThanh || coMana) && bay - lanDocThanh > 1200) {
                    lanDocThanh = bay
                    val anh = chupManHinh(anBang = false)
                    if (anh != null) {
                        if (coThanh) mau = docThanh(anh, "mau_trai", "mau_phai", true)
                        if (coMana) mana = docThanh(anh, "mana_trai", "mana_phai", false)
                        anh.recycle()
                    }
                }

                // 2) Uống bình khi thấp
                val m = mau
                if (m != null && m < cd.nguongMau && bay - lanUongMau > 2500 && chamDiem("binh_mau")) {
                    lanUongMau = bay
                    NhatKy.ghi(this, "Auto: máu $m% -> uống bình máu")
                    Thread.sleep(200)
                }
                val mn = mana
                if (mn != null && mn < cd.nguongMana && bay - lanUongMana > 2500 && chamDiem("binh_mana")) {
                    lanUongMana = bay
                    NhatKy.ghi(this, "Auto: mana $mn% -> uống bình mana")
                    Thread.sleep(200)
                }

                // 3) Làm nhiệm vụ: bấm dòng nhiệm vụ để nhân vật tự đi, rồi bấm tiếp hội thoại
                if (cd.autoCheDo == "nhiem_vu" && bay - lanNhiemVu > cd.giayNhiemVu * 1000L) {
                    lanNhiemVu = bay
                    if (chamDiem("nhiem_vu")) {
                        Thread.sleep(1500)
                        repeat(2) {
                            if (dangChay && chamDiem("hoi_thoai")) Thread.sleep(700)
                        }
                    }
                }

                // 4) Đi tuần: đẩy cần điều khiển về một hướng ngẫu nhiên
                if (cd.giayDiTuan > 0 && bay - lanDiTuan > cd.giayDiTuan * 1000L) {
                    lanDiTuan = bay
                    val tam = toaDo("joystick")
                    if (tam != null) {
                        val goc = Math.random() * Math.PI * 2
                        val r = kichThuocManHinh().second * 0.08
                        cuChi(Path().apply {
                            moveTo(tam.first, tam.second)
                            lineTo((tam.first + r * Math.cos(goc)).toFloat(), (tam.second + r * Math.sin(goc)).toFloat())
                        }, 900)
                    }
                }

                // 5) Kỹ năng theo hồi chiêu, rồi đánh thường
                for (k in kyNang) {
                    if (!dangChay) break
                    val cu = lanKyNang[k] ?: 0L
                    if (bay - cu > (cd.giayHoiChieu * 1000).toLong()) {
                        if (chamDiem(k)) lanKyNang[k] = System.currentTimeMillis()
                        Thread.sleep(150)
                    }
                }
                chamDiem("danh")
                soLan++

                if (soLan % 5 == 0L) {
                    val phut = (System.currentTimeMillis() - batDau) / 60000
                    hienTrangThai(
                        "Auto ${phut}p" +
                            (if (mau != null) " · Máu ${mau}%" else "") +
                            (if (mana != null) " · Mana ${mana}%" else "")
                    )
                }
                Thread.sleep(450)
            }
            NhatKy.ghi(this, "=== Auto dừng")
            hienTrangThai("Auto đã dừng")
        } catch (e: Exception) {
            NhatKy.ghi(this, "LỖI Auto: ${e.message}")
            dangChay = false
            hienTrangThai("Lỗi Auto: ${e.message}")
        }
        dangChay = false
        hienTrangThai("Auto đã dừng")
    }

    // ------------------------------------------------------------ vòng lặp chính
    private fun vongLap(cd: CaiDat) {
        val claude = NhaCungCap.tao(cd.apiKey, cd.model)
        val soTay = SoTay(this)
        val lichSu = ArrayList<String>()
        val heThong = Prompts.heThong(cd.cheDo, cd.ghiChu)
        NhatKy.ghi(this, "=== Bắt đầu: chế độ ${cd.cheDo}, " + NhaCungCap.ten(cd.apiKey) + ", tối đa ${cd.soBuoc} bước")

        try {
            for (buoc in 1..cd.soBuoc) {
                if (!dangChay) break
                val goc = chupManHinh()
                if (goc == null) {
                    hienTrangThai("Không chụp được màn hình, thử lại")
                    Thread.sleep(2000)
                    continue
                }
                val rong = goc.width
                val cao = goc.height
                val tiLe = min(1.0, CANH_DAI_ANH.toDouble() / max(rong, cao))
                val nho = if (tiLe < 1.0)
                    Bitmap.createScaledBitmap(goc, (rong * tiLe).toInt(), (cao * tiLe).toInt(), true)
                else goc
                val bos = ByteArrayOutputStream()
                nho.compress(Bitmap.CompressFormat.JPEG, 80, bos)
                val b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
                val rongNho = nho.width
                val caoNho = nho.height
                if (nho !== goc) nho.recycle()
                goc.recycle()

                hienTrangThai("B$buoc: đang suy nghĩ...")
                val kq = claude.hoi(
                    heThong,
                    Prompts.luot(soTay.ds(), lichSu.takeLast(SO_BUOC_NHO), buoc, rongNho, caoNho),
                    b64
                )
                if (!dangChay) break

                val ds = kq.optJSONArray("thao_tac") ?: JSONArray()
                val moTa = ArrayList<String>()
                for (i in 0 until min(ds.length(), 5)) {
                    if (!dangChay) break
                    val tt = ds.optJSONObject(i) ?: continue
                    moTa.add(runCatching { thucHien(tt, tiLe, rong, cao) }
                        .getOrElse { "lỗi thao tác: ${it.message}" })
                    Thread.sleep(250)
                }

                val suyNghi = kq.optString("suy_nghi")
                val dong = "[$buoc] ${kq.optString("tinh_trang")} | $suyNghi => ${moTa.joinToString("; ")}"
                lichSu.add(dong)
                NhatKy.ghi(this, dong)
                hienTrangThai("B$buoc: $suyNghi")

                val ghi = kq.optString("ghi_so_tay", "").trim()
                if (ghi.isNotEmpty()) soTay.them(ghi)

                Thread.sleep((cd.choGiay * 1000).toLong().coerceIn(0, 30_000))
            }
            NhatKy.ghi(this, "=== Đã dừng")
            dangChay = false
            hienTrangThai("AI đã dừng")
        } catch (e: Exception) {
            NhatKy.ghi(this, "LỖI: ${e.message}")
            dangChay = false
            hienTrangThai("Lỗi: ${e.message}")
        }
    }

    // ------------------------------------------------------------ chụp màn hình
    private fun chupManHinh(anBang: Boolean = true): Bitmap? {
        // Ẩn bảng nút nổi để không lọt vào ảnh gửi AI
        if (anBang) {
            main.post { bang?.visibility = View.INVISIBLE }
            Thread.sleep(150)
        }
        val xong = CountDownLatch(1)
        var ketQua: Bitmap? = null
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    try {
                        val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                        ketQua = hw?.copy(Bitmap.Config.ARGB_8888, false)
                        hw?.recycle()
                        r.hardwareBuffer.close()
                    } catch (_: Exception) {
                    }
                    xong.countDown()
                }

                override fun onFailure(errorCode: Int) {
                    xong.countDown()
                }
            })
            xong.await(6, TimeUnit.SECONDS)
        } finally {
            if (anBang) main.post { if (lopGhi == null) bang?.visibility = View.VISIBLE }
        }
        return ketQua
    }

    // ------------------------------------------------------------ thao tác
    private fun cuChi(path: Path, ms: Long): Boolean {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, ms.coerceIn(1, 10_000)))
            .build()
        val xong = CountDownLatch(1)
        var ok = false
        main.post {
            val gui = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    ok = true; xong.countDown()
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    xong.countDown()
                }
            }, null)
            if (!gui) xong.countDown()
        }
        xong.await(ms + 3000, TimeUnit.MILLISECONDS)
        return ok
    }

    private fun thucHien(t: JSONObject, tiLe: Double, rong: Int, cao: Int): String {
        fun qx(k: String) = (t.optDouble(k, 0.0) / tiLe).coerceIn(0.0, (rong - 1).toDouble()).toFloat()
        fun qy(k: String) = (t.optDouble(k, 0.0) / tiLe).coerceIn(0.0, (cao - 1).toDouble()).toFloat()
        val msGoc = t.optDouble("ms", 0.0)
        val ms = (if (msGoc.isNaN()) 0.0 else msGoc).coerceIn(0.0, 8000.0).toLong()

        return when (t.optString("loai")) {
            "cham" -> {
                val x = qx("x"); val y = qy("y")
                val ok = cuChi(Path().apply { moveTo(x, y) }, 60)
                "chạm (${x.toInt()},${y.toInt()})" + if (ok) "" else " [không được]"
            }
            "giu_vuot" -> {
                val x = qx("x"); val y = qy("y"); val x2 = qx("x2"); val y2 = qy("y2")
                val d = if (ms > 0) ms else 1000
                cuChi(Path().apply { moveTo(x, y); lineTo(x2, y2) }, d)
                "vuốt (${x.toInt()},${y.toInt()})->(${x2.toInt()},${y2.toInt()}) ${d}ms"
            }
            "giu" -> {
                val x = qx("x"); val y = qy("y")
                val d = if (ms > 0) ms else 800
                cuChi(Path().apply { moveTo(x, y) }, d)
                "giữ (${x.toInt()},${y.toInt()}) ${d}ms"
            }
            "quay_lai" -> {
                performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                "quay lại"
            }
            "cho" -> {
                val d = if (ms > 0) ms else 2000
                Thread.sleep(d)
                "chờ ${d}ms"
            }
            else -> "bỏ qua thao tác lạ"
        }
    }
}
