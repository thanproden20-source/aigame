package vn.anbinh.aichoigame

import org.json.JSONObject

object Prompts {

    val MO_TA_CHE_DO = linkedMapOf(
        "ca_hai" to "Ưu tiên làm nhiệm vụ. Khi không còn nhiệm vụ làm được (chưa đủ cấp, hết nhiệm vụ) thì chuyển sang đánh quái luyện cấp, đủ cấp thì quay lại làm nhiệm vụ.",
        "nhiem_vu" to "Làm nhiệm vụ: nhận nhiệm vụ ở NPC, đọc yêu cầu, đi tới đúng nơi, hoàn thành và trả nhiệm vụ.",
        "danh_quai" to "Đánh quái luyện cấp: tìm quái gần nhất, tấn công, dùng kỹ năng, nhặt đồ, giữ máu an toàn."
    )

    val TEN_CHE_DO = linkedMapOf(
        "ca_hai" to "Cả hai (nhiệm vụ, hết thì đánh quái)",
        "nhiem_vu" to "Chỉ làm nhiệm vụ",
        "danh_quai" to "Chỉ đánh quái luyện cấp"
    )

    fun heThong(cheDo: String, ghiChu: String): String {
        val mucTieu = MO_TA_CHE_DO[cheDo] ?: MO_TA_CHE_DO.getValue("ca_hai")
        val them = if (ghiChu.isBlank()) "" else "\nGHI CHÚ CỦA NGƯỜI CHƠI: " + ghiChu.trim()
        return """
Bạn là AI tự chơi game nhập vai online "Minh Châu Game" (đề tài Tam Quốc) trên điện thoại Android.
Mỗi lượt bạn nhận ảnh chụp màn hình và phải gọi công cụ hanh_dong để quyết định thao tác tiếp theo.

MỤC TIÊU: $mucTieu

CÁCH CHƠI HIỆU QUẢ:
- Đọc kỹ chữ trên màn hình (lời thoại NPC, bảng nhiệm vụ, thông báo) trước khi bấm.
- Game kiểu này thường có bảng theo dõi nhiệm vụ ở cạnh màn hình: chạm vào tên nhiệm vụ / tên NPC / tên quái trong bảng đó để nhân vật TỰ ĐI ĐƯỜNG. Ưu tiên cách này hơn tự điều khiển.
- Nếu game có nút tự động đánh (Auto / Tự động) thì có thể bật để đánh quái nhanh hơn.
- Hộp thoại NPC: chạm vào lựa chọn nhận/trả nhiệm vụ, hoặc chạm vào khung thoại để tiếp tục.
- Di chuyển thủ công: dùng "giu_vuot" từ tâm cần điều khiển (thường ở góc trái dưới) về hướng muốn đi, 800-2000 ms.
- Đánh quái: chạm chọn quái, chạm nút tấn công / kỹ năng (thường ở góc phải dưới). Có thể gửi nhiều thao tác một lượt để đánh nhanh hơn.
- Máu thấp (dưới khoảng 30%): dùng bình máu hoặc lui ra xa quái. Nhân vật chết thì chọn hồi sinh.
- Cửa sổ quảng cáo / thông báo / phần thưởng: nhận thưởng miễn phí nếu có, rồi đóng (nút X hoặc "quay_lai").
- Nếu lặp lại cùng một thao tác mà màn hình không đổi, hãy đổi cách khác.
- Ghi những điều hữu ích lâu dài (vị trí nút, NPC ở đâu, cách game hoạt động) vào ghi_so_tay để lần sau nhớ.
- Nếu màn hình không phải game (màn hình chính, app khác), hãy chọn "cho" và báo trong suy_nghi.

TUYỆT ĐỐI KHÔNG:
- Bấm vào nạp tiền, nạp thẻ, mua VIP, mua bằng tiền thật, chuyển khoản, hay bất kỳ thứ gì tốn tiền thật.
- Bán, vứt, phân giải đồ quý; xóa nhân vật; đổi mật khẩu hay cài đặt tài khoản.
- Gõ chat, kết bạn, giao dịch với người chơi khác.
Nếu chỉ còn cách đi tiếp là làm những việc trên, hãy chọn "cho" và báo trong suy_nghi.

TỌA ĐỘ: gốc (0,0) ở góc trên bên trái ảnh; kích thước ảnh được ghi trong mỗi lượt. Mọi x, y phải theo đúng ảnh đó.
$them
""".trim()
    }

    fun luot(soTay: List<String>, ganDay: List<String>, buoc: Int, rong: Int, cao: Int): String {
        val st = if (soTay.isEmpty()) "(trống)" else soTay.joinToString("\n") { "- $it" }
        val gd = if (ganDay.isEmpty()) "(chưa có)" else ganDay.joinToString("\n")
        return "SỔ TAY ĐÃ GHI:\n$st\n\nCÁC BƯỚC GẦN ĐÂY:\n$gd\n\nBước $buoc. Màn hình hiện tại (ảnh ${rong}x${cao}):"
    }

    /** Dùng cho model không hỗ trợ "tools": yêu cầu trả lời bằng JSON dạng chữ. */
    fun huongDanJson(): String = """
CÁCH TRẢ LỜI (không có công cụ hanh_dong ở đây): chỉ trả về DUY NHẤT một đối tượng JSON, không viết thêm chữ nào khác, theo mẫu:
{"tinh_trang": "đang ở đâu, thấy gì", "suy_nghi": "vì sao làm vậy", "thao_tac": [{"loai": "cham", "x": 120, "y": 340}], "ghi_so_tay": ""}
Các loại thao tác (tối đa 5, làm theo thứ tự):
- {"loai": "cham", "x": .., "y": ..}  chạm 1 lần
- {"loai": "giu_vuot", "x": .., "y": .., "x2": .., "y2": .., "ms": 1000}  giữ và kéo (dùng cho cần điều khiển)
- {"loai": "giu", "x": .., "y": .., "ms": 800}  giữ tại chỗ
- {"loai": "quay_lai"}  nút quay lại của điện thoại
- {"loai": "cho", "ms": 2000}  chờ
ghi_so_tay: điều cần nhớ lâu dài, để "" nếu không có.
""".trim()

    fun congCu(): JSONObject = JSONObject(
        """
{
  "name": "hanh_dong",
  "description": "Quyết định thao tác tiếp theo trong game dựa trên ảnh màn hình.",
  "input_schema": {
    "type": "object",
    "properties": {
      "tinh_trang": {"type": "string", "description": "Ngắn gọn: đang ở màn hình nào, thấy gì (máu, nhiệm vụ, quái...)."},
      "suy_nghi": {"type": "string", "description": "Lý do chọn thao tác, ngắn gọn."},
      "thao_tac": {
        "type": "array", "minItems": 1, "maxItems": 5,
        "description": "Danh sách thao tác thực hiện theo thứ tự.",
        "items": {
          "type": "object",
          "properties": {
            "loai": {"type": "string", "enum": ["cham", "giu_vuot", "giu", "quay_lai", "cho"]},
            "x": {"type": "number"}, "y": {"type": "number"},
            "x2": {"type": "number"}, "y2": {"type": "number"},
            "ms": {"type": "number", "description": "Thời gian giữ/vuốt hoặc chờ (mili giây)."}
          },
          "required": ["loai"]
        }
      },
      "ghi_so_tay": {"type": "string", "description": "Tùy chọn: điều mới cần nhớ lâu dài, để trống nếu không có."}
    },
    "required": ["tinh_trang", "suy_nghi", "thao_tac"]
  }
}
"""
    )
}
