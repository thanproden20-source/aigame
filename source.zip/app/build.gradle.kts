plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "vn.anbinh.aichoigame"
    compileSdk = 34

    defaultConfig {
        applicationId = "vn.anbinh.aichoigame"
        minSdk = 30          // Android 11+: cần để Trợ năng chụp được màn hình
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
    }
    signingConfigs {
        create("caNhan") {
            storeFile = file("aichoigame.jks")
            storePassword = "aichoigame123"
            keyAlias = "aichoigame"
            keyPassword = "aichoigame123"
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
        }
    }
    buildTypes {
        // Bản "debug" được chỉnh như bản phát hành: tắt chế độ gỡ lỗi, ký bằng khóa cố định
        // (cập nhật bản mới không cần gỡ app cũ, và dễ qua kiểm tra cài đặt của máy hơn)
        getByName("debug") {
            isDebuggable = false
            signingConfig = signingConfigs.getByName("caNhan")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("caNhan")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
