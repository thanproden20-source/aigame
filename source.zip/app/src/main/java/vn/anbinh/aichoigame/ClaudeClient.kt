package vn.anbinh.aichoigame

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Lỗi không nên thử lại (sai key, hết tiền...). */
class LoiNghiemTrong(msg: String) : Exception(msg)

class ClaudeClient(private val key: String, private val model: String) {

    fun hoi(heThong: String, chu: String, anhB64: String): JSONObject {
        val noiDung = JSONArray()
            .put(JSONObject().put("type", "text").put("text", chu))
            .put(
                JSONObject().put("type", "image").put(
                    "source", JSONObject()
                        .put("type", "base64")
                        .put("media_type", "image/jpeg")
                        .put("data", anhB64)
                )
            )
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 1024)
            .put(
                "system", JSONArray().put(
                    JSONObject().put("type", "text").put("text", heThong)
                        .put("cache_control", JSONObject().put("type", "ephemeral"))
                )
            )
            .put("tools", JSONArray().put(Prompts.congCu()))
            .put("tool_choice", JSONObject().put("type", "tool").put("name", "hanh_dong"))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", noiDung)))
            .toString()

        var loiCuoi = ""
        for (lan in 0 until 4) {
            try {
                val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 20_000
                c.readTimeout = 120_000
                c.setRequestProperty("x-api-key", key)
                c.setRequestProperty("anthropic-version", "2023-06-01")
                c.setRequestProperty("content-type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

                val ma = c.responseCode
                val luong = if (ma in 200..299) c.inputStream else c.errorStream
                val txt = luong?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                c.disconnect()

                when {
                    ma in 200..299 -> {
                        val ct = JSONObject(txt).optJSONArray("content") ?: JSONArray()
                        for (i in 0 until ct.length()) {
                            val k = ct.getJSONObject(i)
                            if (k.optString("type") == "tool_use") return k.getJSONObject("input")
                        }
                        loiCuoi = "AI không trả về thao tác"
                    }
                    ma == 401 || ma == 403 -> throw LoiNghiemTrong("API key sai hoặc không có quyền")
                    ma == 400 -> throw LoiNghiemTrong("Bị từ chối (kiểm tra tên model, số dư tài khoản): " + txt.take(200))
                    else -> loiCuoi = "máy chủ AI bận (mã $ma)"
                }
            } catch (e: LoiNghiemTrong) {
                throw e
            } catch (e: Exception) {
                loiCuoi = "lỗi mạng: " + (e.message ?: e.javaClass.simpleName)
            }
            Thread.sleep(5000L * (lan + 1))
        }
        throw LoiNghiemTrong("Gọi AI thất bại: $loiCuoi")
    }
}
