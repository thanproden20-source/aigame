package vn.anbinh.aichoigame

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Gọi Google Gemini API (có gói miễn phí). Key dạng "AIza...". */
class GeminiClient(private val key: String, private val model: String) : AiClient {

    private var lanGoiCuoi = 0L

    /** Bỏ các trường Gemini có thể không nhận trong schema. */
    private fun lamSach(o: JSONObject): JSONObject {
        val kq = JSONObject()
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            if (k == "minItems" || k == "maxItems") continue
            val v = o.get(k)
            kq.put(k, when (v) {
                is JSONObject -> lamSach(v)
                is JSONArray -> {
                    val a = JSONArray()
                    for (i in 0 until v.length()) {
                        val x = v.get(i)
                        a.put(if (x is JSONObject) lamSach(x) else x)
                    }
                    a
                }
                else -> v
            })
        }
        return kq
    }

    override fun hoi(heThong: String, chu: String, anhB64: String): JSONObject {
        val cc = Prompts.congCu()
        val khaiBao = JSONObject()
            .put("name", cc.getString("name"))
            .put("description", cc.getString("description"))
            .put("parameters", lamSach(cc.getJSONObject("input_schema")))

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", heThong))))
            .put(
                "contents", JSONArray().put(
                    JSONObject().put("role", "user").put(
                        "parts", JSONArray()
                            .put(JSONObject().put("text", chu))
                            .put(
                                JSONObject().put(
                                    "inline_data", JSONObject()
                                        .put("mime_type", "image/jpeg")
                                        .put("data", anhB64)
                                )
                            )
                    )
                )
            )
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", JSONArray().put(khaiBao))))
            .put(
                "toolConfig", JSONObject().put(
                    "functionCallingConfig", JSONObject()
                        .put("mode", "ANY")
                        .put("allowedFunctionNames", JSONArray().put("hanh_dong"))
                )
            )
            .toString()

        var loiCuoi = ""
        for (lan in 0 until 5) {
            // Gói miễn phí giới hạn số lượt mỗi phút: giữ khoảng cách tối thiểu 6 giây giữa 2 lượt
            val cho = 6000L - (System.currentTimeMillis() - lanGoiCuoi)
            if (cho > 0) Thread.sleep(cho)
            lanGoiCuoi = System.currentTimeMillis()
            try {
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                    .openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.doOutput = true
                c.connectTimeout = 20_000
                c.readTimeout = 120_000
                c.setRequestProperty("x-goog-api-key", key)
                c.setRequestProperty("content-type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

                val ma = c.responseCode
                val luong = if (ma in 200..299) c.inputStream else c.errorStream
                val txt = luong?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                c.disconnect()

                when {
                    ma in 200..299 -> {
                        val ung = JSONObject(txt).optJSONArray("candidates")?.optJSONObject(0)
                        val parts = ung?.optJSONObject("content")?.optJSONArray("parts") ?: JSONArray()
                        for (i in 0 until parts.length()) {
                            val fc = parts.optJSONObject(i)?.optJSONObject("functionCall") ?: continue
                            return fc.optJSONObject("args") ?: JSONObject()
                        }
                        loiCuoi = "AI không trả về thao tác"
                    }
                    ma == 400 && txt.contains("API_KEY_INVALID") -> throw LoiNghiemTrong("Key Gemini sai")
                    ma == 401 || ma == 403 -> throw LoiNghiemTrong("Key Gemini sai hoặc không có quyền")
                    ma == 404 -> throw LoiNghiemTrong("Không có model \"$model\". Sửa ô Model AI (ví dụ gemini-flash-latest)")
                    ma == 400 -> throw LoiNghiemTrong("Gemini từ chối: " + txt.take(200))
                    ma == 429 -> {
                        loiCuoi = "hết lượt miễn phí (đợi một lát, hoặc hết lượt trong ngày)"
                        Thread.sleep(20_000L * (lan + 1))
                        continue
                    }
                    else -> loiCuoi = "máy chủ Gemini bận (mã $ma)"
                }
            } catch (e: LoiNghiemTrong) {
                throw e
            } catch (e: Exception) {
                loiCuoi = "lỗi mạng: " + (e.message ?: e.javaClass.simpleName)
            }
            Thread.sleep(5000L * (lan + 1))
        }
        throw LoiNghiemTrong("Gọi Gemini thất bại: $loiCuoi")
    }
}
