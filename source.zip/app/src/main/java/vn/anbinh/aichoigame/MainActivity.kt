package vn.anbinh.aichoigame

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var trangThai: TextView
    private lateinit var nhatKy: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cd = CaiDat.doc(this)
        val dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()

        val goc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad * 3)
        }
        fun nhan(s: String) = TextView(this).apply {
            text = s
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, pad, 0, 4)
        }

        goc.addView(TextView(this).apply {
            text = "AI Chơi Game"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
        })
        trangThai = TextView(this).apply { textSize = 15f; setPadding(0, pad / 2, 0, pad / 2) }
        goc.addView(trangThai)

        goc.addView(Button(this).apply {
            text = "Bật quyền Trợ năng cho app"
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Tìm \"AI Chơi Game\" trong danh sách và bật lên", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        goc.addView(Button(this).apply {
            text = "Mở thông tin app (nếu bị chặn bật Trợ năng)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = android.net.Uri.parse("package:$packageName")
                })
            }
        })

        goc.addView(nhan("API key (Claude hoặc Gemini)"))
        val oKey = EditText(this).apply {
            setText(cd.apiKey)
            hint = "sk-ant-... (Claude) hoặc AIza... (Gemini)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            isSingleLine = true
        }
        goc.addView(oKey)

        goc.addView(nhan("Việc AI làm"))
        val nhom = RadioGroup(this)
        val idTheoCheDo = HashMap<Int, String>()
        Prompts.TEN_CHE_DO.forEach { (ma, ten) ->
            val rb = RadioButton(this).apply { text = ten; id = View.generateViewId() }
            idTheoCheDo[rb.id] = ma
            nhom.addView(rb)
            if (ma == cd.cheDo) nhom.check(rb.id)
        }
        goc.addView(nhom)

        goc.addView(nhan("Model AI"))
        val oModel = EditText(this).apply { setText(cd.model); isSingleLine = true }
        goc.addView(oModel)
        goc.addView(TextView(this).apply {
            text = "Để trống là tự chọn theo loại key.\nClaude: claude-sonnet-5-5 (khuyên dùng), claude-haiku-5-5 (rẻ hơn).\nGemini miễn phí: gemini-flash-latest, hết lượt thì thử gemini-flash-lite-latest."
            textSize = 12f
            setTextColor(Color.GRAY)
        })

        goc.addView(nhan("Số bước tối đa mỗi lần chạy"))
        val oSoBuoc = EditText(this).apply {
            setText(cd.soBuoc.toString()); inputType = InputType.TYPE_CLASS_NUMBER; isSingleLine = true
        }
        goc.addView(oSoBuoc)

        goc.addView(nhan("Nghỉ giữa các bước (giây)"))
        val oCho = EditText(this).apply {
            setText(cd.choGiay.toString())
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            isSingleLine = true
        }
        goc.addView(oCho)

        goc.addView(nhan("Dặn thêm AI (không bắt buộc)"))
        val oGhiChu = EditText(this).apply {
            setText(cd.ghiChu)
            hint = "Ví dụ: Nhân vật hệ Võ, bình máu ở ô số 4, đánh quái ở bãi phía đông thành"
            minLines = 2
        }
        goc.addView(oGhiChu)

        goc.addView(Button(this).apply {
            text = "LƯU CÀI ĐẶT"
            setOnClickListener {
                CaiDat(
                    apiKey = oKey.text.toString(),
                    model = oModel.text.toString(),
                    cheDo = idTheoCheDo[nhom.checkedRadioButtonId] ?: "ca_hai",
                    soBuoc = oSoBuoc.text.toString().toIntOrNull()?.coerceIn(1, 100_000) ?: 500,
                    choGiay = oCho.text.toString().toDoubleOrNull()?.coerceIn(0.0, 30.0) ?: 1.2,
                    ghiChu = oGhiChu.text.toString()
                ).luu(this@MainActivity)
                Toast.makeText(this@MainActivity, "Đã lưu", Toast.LENGTH_SHORT).show()
                capNhat()
            }
        })

        goc.addView(TextView(this).apply {
            text = "\nCÁCH DÙNG: lưu cài đặt → bật quyền Trợ năng → mở game → bấm nút nổi \"▶ AI\" để AI bắt đầu chơi, bấm lần nữa để dừng. Giữ và kéo nút để dời chỗ."
            textSize = 14f
        })

        goc.addView(nhan("Nhật ký (mới nhất ở trên)"))
        val hang = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hang.addView(Button(this).apply { text = "Tải lại"; setOnClickListener { capNhat() } })
        hang.addView(Button(this).apply {
            text = "Xóa nhật ký"
            setOnClickListener { NhatKy.xoa(this@MainActivity); capNhat() }
        })
        hang.addView(Button(this).apply {
            text = "Xóa sổ tay AI"
            setOnClickListener {
                SoTay(this@MainActivity).xoa()
                Toast.makeText(this@MainActivity, "AI sẽ học lại game từ đầu", Toast.LENGTH_SHORT).show()
            }
        })
        goc.addView(hang)

        nhatKy = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
        }
        goc.addView(nhatKy)

        setContentView(ScrollView(this).apply { addView(goc) })
    }

    override fun onResume() {
        super.onResume()
        capNhat()
    }

    private fun capNhat() {
        val coKey = CaiDat.doc(this).apiKey.isNotBlank()
        trangThai.text = when {
            !coKey -> "⚠️ Chưa có API key. Nhập API key bên dưới rồi bấm LƯU."
            AiService.instance == null -> "⚠️ Chưa bật quyền Trợ năng. Bấm nút bên dưới, tìm \"AI Chơi Game\" và bật lên."
            else -> "✅ Sẵn sàng. Mở game và bấm nút nổi \"▶ AI\" trên màn hình."
        }
        nhatKy.text = NhatKy.doc(this)
    }
}
