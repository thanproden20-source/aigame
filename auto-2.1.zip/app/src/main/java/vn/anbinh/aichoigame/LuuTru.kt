package vn.anbinh.aichoigame

import android.content.Context
import java.io.File

/** Cài đặt chế độ Auto. */
data class CaiDat(
    val autoCheDo: String = "danh_quai",   // danh_quai | nhiem_vu
    val nguongMau: Int = 40,               // % máu thì uống bình
    val nguongMana: Int = 30,
    val giayNhiemVu: Int = 20,             // bao lâu bấm bảng nhiệm vụ 1 lần
    val giayHoiChieu: Double = 3.0,        // hồi chiêu kỹ năng
    val giayDiTuan: Int = 0                // 0 = không đi tuần
) {
    fun luu(c: Context) {
        c.getSharedPreferences(TEN, Context.MODE_PRIVATE).edit()
            .putString("auto_che_do", autoCheDo)
            .putInt("nguong_mau", nguongMau)
            .putInt("nguong_mana", nguongMana)
            .putInt("giay_nhiem_vu", giayNhiemVu)
            .putString("giay_hoi_chieu", giayHoiChieu.toString())
            .putInt("giay_di_tuan", giayDiTuan)
            .apply()
    }

    companion object {
        private const val TEN = "cai_dat"

        fun doc(c: Context): CaiDat {
            val sp = c.getSharedPreferences(TEN, Context.MODE_PRIVATE)
            return CaiDat(
                autoCheDo = sp.getString("auto_che_do", "danh_quai") ?: "danh_quai",
                nguongMau = sp.getInt("nguong_mau", 40),
                nguongMana = sp.getInt("nguong_mana", 30),
                giayNhiemVu = sp.getInt("giay_nhiem_vu", 20),
                giayHoiChieu = (sp.getString("giay_hoi_chieu", "3.0") ?: "3.0").toDoubleOrNull() ?: 3.0,
                giayDiTuan = sp.getInt("giay_di_tuan", 0)
            )
        }
    }
}

/** Nhật ký chạy, lưu trong bộ nhớ riêng của app. */
object NhatKy {
    private fun file(c: Context) = File(c.filesDir, "nhat_ky.txt")

    @Synchronized
    fun ghi(c: Context, dong: String) {
        val f = file(c)
        if (f.exists() && f.length() > 300_000) {
            val giu = f.readLines().takeLast(400)
            f.writeText(giu.joinToString("\n") + "\n")
        }
        val gio = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        f.appendText("$gio $dong\n")
    }

    fun doc(c: Context, soDong: Int = 60): String {
        val f = file(c)
        if (!f.exists()) return "(chưa có nhật ký)"
        return f.readLines().takeLast(soDong).reversed().joinToString("\n")
    }

    fun xoa(c: Context) {
        file(c).delete()
    }
}

/** Một vị trí trên màn hình game cần ghi lại. */
data class Diem(val ma: String, val ten: String, val batBuoc: Boolean)

/** Vị trí các nút trong game, lưu theo tỉ lệ màn hình (0..1). */
object ViTri {
    val DS = listOf(
        Diem("danh", "nút ĐÁNH (tấn công)", true),
        Diem("kn1", "nút KỸ NĂNG 1", false),
        Diem("kn2", "nút KỸ NĂNG 2", false),
        Diem("kn3", "nút KỸ NĂNG 3", false),
        Diem("kn4", "nút KỸ NĂNG 4", false),
        Diem("mau_trai", "ĐẦU TRÁI của thanh MÁU (đỏ)", false),
        Diem("mau_phai", "ĐẦU PHẢI của thanh MÁU (đỏ)", false),
        Diem("binh_mau", "ô BÌNH MÁU", false),
        Diem("mana_trai", "ĐẦU TRÁI của thanh MANA (xanh)", false),
        Diem("mana_phai", "ĐẦU PHẢI của thanh MANA (xanh)", false),
        Diem("binh_mana", "ô BÌNH MANA", false),
        Diem("nhiem_vu", "DÒNG NHIỆM VỤ đầu tiên trong bảng Nhiệm vụ", false),
        Diem("hoi_thoai", "chỗ bấm TIẾP TỤC khi nói chuyện với NPC", false),
        Diem("joystick", "TÂM cần điều khiển (vòng tròn góc trái dưới)", false)
    )

    private fun sp(c: Context) = c.getSharedPreferences("vi_tri", Context.MODE_PRIVATE)

    fun luu(c: Context, ma: String, tx: Float, ty: Float) {
        sp(c).edit().putFloat(ma + "_x", tx).putFloat(ma + "_y", ty).apply()
    }

    /** Trả về (tỉ lệ x, tỉ lệ y) hoặc null nếu chưa ghi. */
    fun lay(c: Context, ma: String): Pair<Float, Float>? {
        val s = sp(c)
        if (!s.contains(ma + "_x")) return null
        return Pair(s.getFloat(ma + "_x", 0f), s.getFloat(ma + "_y", 0f))
    }

    fun soDaGhi(c: Context) = DS.count { lay(c, it.ma) != null }

    fun xoa(c: Context) = sp(c).edit().clear().apply()
}
