package vn.anbinh.aichoigame

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var trangThai: TextView
    private lateinit var soViTri: TextView
    private lateinit var nhatKy: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cd = CaiDat.doc(this)
        val dp = resources.displayMetrics.density
        val pad = (16 * dp).toInt()

        val goc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad * 3)
        }
        fun nhan(s: String) = TextView(this).apply {
            text = s
            textSize = 15f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, pad, 0, 4)
        }

        goc.addView(TextView(this).apply {
            text = "Auto Minh Châu Game"
            textSize = 24f
            setTypeface(null, Typeface.BOLD)
        })
        goc.addView(TextView(this).apply {
            text = "Auto viết riêng cho Minh Châu Game: vị trí nút đã đo sẵn, không dùng AI, không cần mạng."
            textSize = 14f
            setTextColor(Color.GRAY)
        })
        trangThai = TextView(this).apply { textSize = 15f; setPadding(0, pad / 2, 0, 0) }
        goc.addView(trangThai)
        soViTri = TextView(this).apply { textSize = 15f; setPadding(0, 4, 0, pad / 2) }
        goc.addView(soViTri)

        goc.addView(Button(this).apply {
            text = "Bật quyền Trợ năng cho app"
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Tìm \"Auto Minh Châu\" trong danh sách và bật lên", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        goc.addView(Button(this).apply {
            text = "Mở thông tin app (nếu bị chặn bật Trợ năng)"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = android.net.Uri.parse("package:$packageName")
                })
            }
        })

        goc.addView(TextView(this).apply {
            text = "\nCÁCH DÙNG\n1) Mở Minh Châu Game, vào bản đồ. Phía trên màn hình có bảng nút nổi: ▶ Auto · ☰ Cài đặt\n" +
                "2) Bấm ▶ Auto là chạy ngay (vị trí nút đã đo sẵn). Bấm lần nữa để dừng.\n" +
                "3) Chỉnh mức máu, mana, hồi chiêu... trong ☰ Cài đặt. Bấm Xem vị trí để kiểm tra vòng tím có trúng nút không; lệch thì bấm Chỉnh vị trí.\n" +
                "Auto không bao giờ bấm vào vùng nút Ủng hộ / nạp tiền."
            textSize = 14f
        })

        goc.addView(nhan("Auto làm gì"))
        val nhom = RadioGroup(this)
        val rbDanh = RadioButton(this).apply { text = "Đánh quái tại chỗ (treo luyện cấp)"; id = View.generateViewId() }
        val rbNv = RadioButton(this).apply { text = "Làm nhiệm vụ (bấm bảng nhiệm vụ để tự đi) + đánh"; id = View.generateViewId() }
        nhom.addView(rbDanh)
        nhom.addView(rbNv)
        nhom.check(if (cd.autoCheDo == "nhiem_vu") rbNv.id else rbDanh.id)
        goc.addView(nhom)

        fun oSo(nhanChu: String, giaTri: String, thapPhan: Boolean = false): EditText {
            goc.addView(nhan(nhanChu))
            val o = EditText(this).apply {
                setText(giaTri)
                inputType = InputType.TYPE_CLASS_NUMBER or (if (thapPhan) InputType.TYPE_NUMBER_FLAG_DECIMAL else 0)
                isSingleLine = true
            }
            goc.addView(o)
            return o
        }
        val oMau = oSo("Uống bình máu khi máu dưới (%)", cd.nguongMau.toString())
        val oMana = oSo("Uống bình mana khi mana dưới (%)", cd.nguongMana.toString())
        val oHoiChieu = oSo("Hồi chiêu kỹ năng (giây)", cd.giayHoiChieu.toString(), true)
        val oNhiemVu = oSo("Làm nhiệm vụ: bấm bảng nhiệm vụ mỗi (giây)", cd.giayNhiemVu.toString())
        val oDiTuan = oSo("Đi tuần tìm quái mỗi (giây, 0 = đứng yên)", cd.giayDiTuan.toString())

        goc.addView(Button(this).apply {
            text = "LƯU CÀI ĐẶT"
            setOnClickListener {
                CaiDat(
                    autoCheDo = if (nhom.checkedRadioButtonId == rbNv.id) "nhiem_vu" else "danh_quai",
                    nguongMau = oMau.text.toString().toIntOrNull()?.coerceIn(0, 100) ?: 40,
                    nguongMana = oMana.text.toString().toIntOrNull()?.coerceIn(0, 100) ?: 30,
                    giayHoiChieu = oHoiChieu.text.toString().toDoubleOrNull()?.coerceIn(0.2, 120.0) ?: 3.0,
                    giayNhiemVu = oNhiemVu.text.toString().toIntOrNull()?.coerceIn(3, 600) ?: 20,
                    giayDiTuan = oDiTuan.text.toString().toIntOrNull()?.coerceIn(0, 600) ?: 0
                ).luu(this@MainActivity)
                Toast.makeText(this@MainActivity, "Đã lưu. Bấm ▶ Auto lại để áp dụng", Toast.LENGTH_SHORT).show()
                capNhat()
            }
        })
        goc.addView(Button(this).apply {
            text = "Đưa vị trí nút về mặc định"
            setOnClickListener {
                ViTri.xoa(this@MainActivity)
                Toast.makeText(this@MainActivity, "Đã đưa về vị trí đo sẵn", Toast.LENGTH_SHORT).show()
                capNhat()
            }
        })

        goc.addView(nhan("Nhật ký (mới nhất ở trên)"))
        val hang = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hang.addView(Button(this).apply { text = "Tải lại"; setOnClickListener { capNhat() } })
        hang.addView(Button(this).apply {
            text = "Xóa nhật ký"
            setOnClickListener { NhatKy.xoa(this@MainActivity); capNhat() }
        })
        goc.addView(hang)

        nhatKy = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
        }
        goc.addView(nhatKy)

        setContentView(ScrollView(this).apply { addView(goc) })
    }

    override fun onResume() {
        super.onResume()
        capNhat()
    }

    private fun capNhat() {
        trangThai.text = if (AiService.instance == null)
            "⚠️ Chưa bật quyền Trợ năng. Bấm nút bên dưới, tìm \"Auto Minh Châu\" và bật lên."
        else "✅ Đã bật quyền. Mở game là thấy bảng nút nổi ▶ Auto · ☰ Cài đặt"
        val n = ViTri.soDaGhi(this)
        soViTri.text = "✅ Vị trí nút: đo sẵn cho Minh Châu Game" + (if (n > 0) " (đã chỉnh tay $n mục)" else "")
        nhatKy.text = NhatKy.doc(this)
    }
}
