pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
        // Kho dự phòng (bản sao Maven Central) khi kho chính lỗi
        maven("https://maven-central.storage-download.googleapis.com/maven2/")
        maven("https://repo1.maven.org/maven2/")
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven("https://maven-central.storage-download.googleapis.com/maven2/")
        maven("https://repo1.maven.org/maven2/")
    }
}
rootProject.name = "AiChoiGame"
include(":app")
